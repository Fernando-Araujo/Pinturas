# Paint Companion — MVP pessoal

Webapp/PWA para uso pessoal no iPad.

## O que já funciona

- Dashboard de coleção e progresso
- Catálogo inicial de tintas Vallejo editável
- Marcação de estoque e nível do frasco
- Laboratório com círculo cromático
- Sugestões de sombra, base, luz e undercoat
- Cadastro de miniaturas, facções, status e pontos
- Visão Kanban do processo de pintura
- Resumo de pontos por exército
- Uso offline
- Exportação e importação de backup JSON

## Como testar no computador

A pasta precisa ser servida por HTTP; abrir o arquivo diretamente não ativa o modo offline.

Com Python instalado:

```bash
python3 -m http.server 8080
```

Depois abra `http://localhost:8080`.

## Como colocar no iPad

1. Publique esta pasta em um serviço estático, como GitHub Pages, Netlify ou Vercel.
2. Abra o endereço no Safari do iPad.
3. Toque em Compartilhar.
4. Escolha “Adicionar à Tela de Início”.
5. Ative “Abrir como App da Web”, quando essa opção aparecer.

## Dados

Os dados são gravados no armazenamento local do navegador. Use a tela **Dados** para criar backups no iCloud Drive.

## Observação

O catálogo incluído é apenas uma base inicial editável. O próximo passo é importar o catálogo Vallejo completo e adicionar atualização versionada de pontos do Warhammer 40K.
